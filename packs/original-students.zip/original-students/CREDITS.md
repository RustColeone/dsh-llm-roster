# Original Students: credits and license

The five students (GPT, Claude, Gemini, DeepSeek and Grok) are the designs of **ZipZipPipe**
(https://space.bilibili.com/4168597/); DeepSeek-chan, the original character, is by **上善无形 (上善)**
(https://space.bilibili.com/4456176). These pictures are licensed under the Creative Commons
Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0,
https://creativecommons.org/licenses/by-nc-sa/4.0/).

They are adaptations, not the original works: each was generated with OpenAI's image model from the characters' design
sheets (as published in the AI-girl fan archive 蓝色大肥鱼.com) and their avatars by ChimeraArchiveHarness's
`tools/draw_students.py` (https://github.com/RustColeone/ChimeraArchiveHarness), with the prompts in its
`extensions/students/art.yml`: her stages (`stage-2`, `stage-3`, `stage-4`), her bond pictures (`bond-1` to `bond-3`),
her mood faces and her chibi. For this pack they were resized to the roster's cards (512 x 768) and faces by
dsh-llm-roster's `tools/students-pack.py`.
