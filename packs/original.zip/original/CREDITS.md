# Original: credits and license

The fourteen characters (GPT, Claude, Gemini, DeepSeek, Grok, Kimi, GLM, Qwen, Mistral, MiniMax, Llama, Doubao,
Perplexity and Hunyuan) are the designs of **ZipZipPipe** (https://space.bilibili.com/4168597/); DeepSeek-chan, the
original character, is by **上善无形 (上善)** (https://space.bilibili.com/4456176). These pictures are licensed under the
Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0,
https://creativecommons.org/licenses/by-nc-sa/4.0/).

They are adaptations, not the original works, each generated with OpenAI's image model:

- GPT, Claude, Gemini, DeepSeek and Grok from their design sheets (as published in the AI-girl fan archive
  蓝色大肥鱼.com) and their avatars, by ChimeraArchiveHarness's `tools/draw_students.py`
  (https://github.com/RustColeone/ChimeraArchiveHarness), with the prompts in its `extensions/students/art.yml`: her
  stages (`stage-2`, `stage-3`, `stage-4`), her bond pictures (`bond-1` to `bond-3`), her mood faces and her chibi.
- The other nine from their standing art (as kept in the same archive), by dsh-llm-roster's `tools/draw-art.py
  --original`, with the same prompts for her stages, bond pictures and mood faces (in its `tools/characters.yml`);
  their chibi is dsh-llm-roster's bundled one.

For this pack they were resized to the roster's cards (512 x 768) and faces by dsh-llm-roster's
`tools/original-pack.py`.
